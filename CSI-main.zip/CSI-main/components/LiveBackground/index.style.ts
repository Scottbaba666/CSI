/*
 * @Author: tohsaka888
 * @Date: 2022-09-16 15:11:44
 * @LastEditors: tohsaka888
 * @LastEditTime: 2022-09-16 15:12:47
 * @Description: 请填写简介
 */
import styled from 'styled-components'

export const BackgroundContainer = styled.div`
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0px;
  left: 0px;
`