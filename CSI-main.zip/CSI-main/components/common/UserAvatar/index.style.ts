/*
 * @Author: tohsaka888
 * @Date: 2022-09-26 11:14:11
 * @LastEditors: tohsaka888
 * @LastEditTime: 2022-09-26 11:16:13
 * @Description: style
 */

import styled from "styled-components";

export const AvatarContainer = styled.div`
  & .ant-popover-inner-content {
    padding: 0px !important;
  }
`;
